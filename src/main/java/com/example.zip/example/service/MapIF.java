package com.example.service;

public interface MapIF<K,V> {
	public K getKey();
	public V getValue();
}
