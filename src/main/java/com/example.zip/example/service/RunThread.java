package com.example.service;

public interface RunThread {

}
